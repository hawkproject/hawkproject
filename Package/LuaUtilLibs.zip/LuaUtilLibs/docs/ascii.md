ascii.lua
=========
This file contains a table of the ASCII character set, with numeric values and descriptions.  There are routines to create constant values from the table.